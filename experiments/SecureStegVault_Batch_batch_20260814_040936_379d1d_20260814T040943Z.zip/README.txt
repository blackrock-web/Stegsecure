SecureStegVault Batch Export
Job ID: batch_20260814_040936_379d1d
Type: encode
Status: failed
Successful: 0 / 6
Failed: 6
Generated: 20260814T040943Z

Secrets (passphrases, plaintext) are intentionally omitted.
